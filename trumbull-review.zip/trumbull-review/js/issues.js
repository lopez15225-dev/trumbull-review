// Loads all issue JSON files and renders:
// 1. The "Latest Issue" piece grid (most recent published issue)
// 2. The "Archive" grid (every issue, published or upcoming)
//
// To add a new issue file to this list, add its filename here whenever
// you create one through /admin — Decap CMS does not auto-update this
// list file, so this is the one manual step.
const ISSUE_FILES = [
  "issues/issue-02.json",
  "issues/issue-01.json",
  "issues/issue-00.json"
];

const globeSVG = `<svg viewBox="0 0 100 100" fill="none" stroke="#3D2B1F" stroke-width="1" aria-hidden="true">
  <circle cx="50" cy="50" r="40" stroke-width="1.6"/>
  <ellipse cx="50" cy="50" rx="40" ry="14"/>
  <ellipse cx="50" cy="50" rx="40" ry="28"/>
  <ellipse cx="50" cy="50" rx="14" ry="40"/>
  <ellipse cx="50" cy="50" rx="28" ry="40"/>
  <line x1="10" y1="50" x2="90" y2="50" stroke-width="1.4"/>
  <line x1="50" y1="10" x2="50" y2="90" stroke-width="1.4"/>
</svg>`;

const globeSVGDashed = `<svg viewBox="0 0 100 100" fill="none" stroke="#3D2B1F" stroke-width="1" aria-hidden="true">
  <circle cx="50" cy="50" r="40" stroke-width="1.6" stroke-dasharray="2 3"/>
  <line x1="10" y1="50" x2="90" y2="50" stroke-width="1" stroke-dasharray="2 3"/>
  <line x1="50" y1="10" x2="50" y2="90" stroke-width="1" stroke-dasharray="2 3"/>
</svg>`;

async function loadIssues() {
  const results = await Promise.allSettled(
    ISSUE_FILES.map(f => fetch(f).then(r => { if (!r.ok) throw new Error(f); return r.json(); }))
  );
  return results
    .filter(r => r.status === "fulfilled")
    .map(r => r.value)
    .sort((a, b) => (b.issue_number || "").localeCompare(a.issue_number || ""));
}

function renderArchive(issues) {
  const grid = document.getElementById("archiveGrid");
  if (!grid) return;
  grid.innerHTML = issues.map(issue => {
    const upcoming = issue.status === "upcoming";
    return `
      <article class="issue-card${upcoming ? ' upcoming' : ''}">
        <div class="issue-cover">
          <span class="issue-num">Issue ${issue.issue_number}</span>
          ${upcoming ? globeSVGDashed : globeSVG}
        </div>
        <div class="issue-body">
          <h3>${escapeHTML(issue.title)}</h3>
          <div class="issue-date">${escapeHTML(issue.subtitle || "")}</div>
          <p>${escapeHTML(issue.description || "")}</p>
          ${upcoming
            ? `<a href="#" class="btn">Coming soon</a>`
            : `<a href="#showcase" class="btn btn-ghost" data-issue="${issue.issue_number}">Read Issue ${issue.issue_number}</a>`}
        </div>
      </article>`;
  }).join("");
}

function renderLatestIssue(issues) {
  const published = issues.filter(i => i.status === "published");
  if (published.length === 0) return;
  const latest = published[0];

  const eyebrow = document.getElementById("latestIssueEyebrow");
  const pieceGrid = document.getElementById("pieceGrid");
  if (eyebrow) eyebrow.textContent = `Issue ${latest.issue_number} — ${latest.title}`;
  if (!pieceGrid) return;

  pieceGrid.innerHTML = (latest.pieces || []).map(p => `
    <article class="piece">
      <span class="eyebrow">${escapeHTML(p.category)}</span>
      <h3>${escapeHTML(p.title)}</h3>
      <p>${escapeHTML(p.excerpt)}</p>
      <span class="byline">— ${escapeHTML(p.author)}</span>
    </article>
  `).join("");
}

function escapeHTML(str) {
  if (!str) return "";
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

document.addEventListener("DOMContentLoaded", async () => {
  try {
    const issues = await loadIssues();
    renderArchive(issues);
    renderLatestIssue(issues);
  } catch (e) {
    console.error("Could not load issues:", e);
  }
});
